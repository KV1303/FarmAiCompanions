package com.replit.farmassistai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}