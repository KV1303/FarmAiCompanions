# FarmAssistAI - Android Studio Project with Gradle Wrapper Fix

## Setup Instructions

1. Extract this zip file
2. Open the project in Android Studio
3. Wait for Gradle sync to complete
4. Run the app or build APK

## Troubleshooting

If you still encounter Gradle issues:

- Open Android Studio Terminal
- Run: chmod +x ./gradlew
- Try build again
