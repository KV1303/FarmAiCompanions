# FarmAssistAI - Android Studio Project

This directory contains the Flutter project files configured for Android Studio.
